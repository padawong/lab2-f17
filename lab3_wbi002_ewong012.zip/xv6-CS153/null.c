#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
int *i = 0;

(*i)++;

printf(1,"Hi %d",*i);

return 1;
}

